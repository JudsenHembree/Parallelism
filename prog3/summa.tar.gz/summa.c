/******************************************************************************************
*
*	Filename:	summa.c
*	Purpose:	A paritally implemented program for MSCS6060 HW. Students will complete 
*			the program by adding SUMMA implementation for matrix multiplication C = A * B.  
*	Assumptions:    A, B, and C are square matrices n by n; 
*			the total number of processors (np) is a square number (q^2).
*	To compile, use 
*	    mpicc -o summa summa.c
*       To run, use
*	    mpiexec -n $(NPROCS) ./summa
*********************************************************************************************/

#include <stdio.h>
#include <time.h>	
#include <stdlib.h>	
#include <math.h>	
#include "mpi.h"

#define min(a, b) ((a < b) ? a : b)
#define SZ 640
//Each matrix of entire A, B, and C is SZ by SZ. Set a small value for testing, and set a large value for collecting experimental data.


/**
*   Allocate space for a two-dimensional array
*/
double **alloc_2d_double(int n_rows, int n_cols) {
	int i;
	double **array;
	array = (double **)malloc(n_rows * sizeof (double *));
        array[0] = (double *) malloc(n_rows * n_cols * sizeof(double));
        for (i=1; i<n_rows; i++){
                array[i] = array[0] + i * n_cols;
        }
        return array;
}

/**
*	Initialize arrays A and B with random numbers, and array C with zeros. 
*	Each array is setup as a square block of blck_sz.
**/
void initialize(double **lA, double **lB, double **lC, int blck_sz){
	int i, j;
	double value;
	// Set random values...technically it is already random and this is redundant
	for (i=0; i<blck_sz; i++){
		for (j=0; j<blck_sz; j++){
			lA[i][j] = (double)rand() / (double)RAND_MAX;
			lB[i][j] = (double)rand() / (double)RAND_MAX;
			lC[i][j] = 0.0;
		}
	}
}

void initializetoones(double **lA, double **lB, double **lC, int blck_sz){
	int i, j;
	double value;
	// Set random values...technically it is already random and this is redundant
	for (i=0; i<blck_sz; i++){
		for (j=0; j<blck_sz; j++){
			lA[i][j] = 1; 
			lB[i][j] = 1;
			lC[i][j] = 0.0;
		}
	}
}

void matmuladd(double **C, double **A, double **B, int size){
    int j,i,k;
    for ( i = 0; i < size; i++){
        for (j = 0; j < size; j++){
             for ( k = 0; k < size; k++){
                 C[i][j] = C[i][j] + A[i][k] * B[k][j];
             }
         }
     }
}

void copy(double** in,double** out, int block_sz){
    for(int i=0; i<block_sz; i++){
        for(int j=0; j<block_sz; j++){
            out[i][j]=in[i][j];
            //out[i][j]=in[i+(block_sz*block_sz*proc_grid_sz*coordinates[0])][j+(block_sz*coordinates[1])];
            //I think its my copy
        }
    }
}


/**
*	Perform the SUMMA matrix multiplication. 
*       Follow the pseudo code in lecture slides.
*/
void matmul(int my_rank, int proc_grid_sz, int block_sz, double **my_A,
						double **my_B, double **my_C){

	//Add your implementation of SUMMA algorithm
    double **buffA,**buffB;
    buffA=alloc_2d_double(block_sz,block_sz);
    buffB=alloc_2d_double(block_sz,block_sz);
    
    //create grid comm and get coordinates
    //???
	MPI_Comm grid_comm;
	int dimsizes[2];
	int wraparound[2];
	int coordinates[2];
	int free_coords[2];
	int reorder = 1;
	int my_grid_rank, grid_rank;
	int row_test, col_test;

	MPI_Comm row_comm;
	MPI_Comm col_comm;
	
    dimsizes[0] = dimsizes[1] = proc_grid_sz;
	wraparound[0] = wraparound[1] = 1;
	
	MPI_Cart_create(MPI_COMM_WORLD, 2, dimsizes, wraparound, reorder, &grid_comm);
	MPI_Comm_rank(grid_comm, &my_grid_rank);
	MPI_Cart_coords(grid_comm, my_grid_rank, 2, coordinates);
	MPI_Cart_rank(grid_comm, coordinates, &grid_rank);
	
	//printf("Process %d > my_grid_rank = %d, coords = (%d, %d), grid_rank = %d\n", myrank, my_grid_rank, coordinates[0], coordinates[1], grid_rank);
    
	
	free_coords[0] = 0;
	free_coords[1] = 1;
	MPI_Cart_sub(grid_comm,free_coords, &row_comm);
    
    /*
	if(coordinates[1] == 0)
		row_test = coordinates[0];
	else
		row_test = -1;
	MPI_Bcast(&row_test, 1, MPI_INT, 0, row_comm);
	printf("Process %d > coords = (%d, %d), row_test = %d\n", my_rank, coordinates[0], coordinates[1], row_test);
    */
	
	free_coords[0] = 1;
	free_coords[1] = 0;
	MPI_Cart_sub(grid_comm, free_coords, &col_comm);
    /*
	if(coordinates[0] == 0)
		col_test = coordinates[1];
	else
		col_test= -1;
	MPI_Bcast(&col_test, 1, MPI_INT, 0, col_comm);
	printf("Process %d > coords = (%d, %d), col_test = %d\n", my_rank, coordinates[0], coordinates[1], col_test);
    */
   
	
    for(int k=0; k<proc_grid_sz; k++){
        if(coordinates[1]==k){
           //create a func to iterate through copy
           copy(my_A, buffA, block_sz);
           //buffA=my_A; 
           
        }
        MPI_Bcast(*buffA, block_sz*block_sz, MPI_DOUBLE, k, row_comm);
        if(coordinates[0]==k){
            copy(my_B, buffB, block_sz);
           //buffB=my_B; 
        }
        MPI_Bcast(*buffB, block_sz*block_sz, MPI_DOUBLE, k, col_comm);
        
        if(coordinates[0]==k && coordinates[1]==k){
            matmuladd(my_C, my_A, my_B, block_sz);
        }else if(coordinates[0]==k){
            matmuladd(my_C, buffA, my_B, block_sz);
        }else if(coordinates[1]==k){
            matmuladd(my_C, my_A, buffB, block_sz);
        }else{
            matmuladd(my_C, buffA, buffB, block_sz);
        }
    }
}

void tradMult(double** mat1, double** mat2, double**out) {
    for (int i = 0; i < 6 ; i++) {
        for (int j = 0; j < 6; j++) {
            out[i][j] = 0;
            double sum=0;
            for (int k = 0; k < 6; k++) {
                 out[i][j]=out[i][j]+mat1[i][k] * mat2[k][j];
            }
 
            //printf("%d, ",out[i][j]);
        }
        //printf("\n");
    }
}


/*void printDiff()
{
    printf("Listing first %d Differences > %.6f...\n", iListLength, fListTol);
    int i,j,k;
    int error_count=0;

    for (j = 0; j < height; j++)
    {
        if (error_count < iListLength)
        {
            printf("\n  Row %d:\n", j);
        }

        for (i = 0; i < width; i++)
        {
            k = j * width + i;
            float fDiff = fabs(data1[k] - data2[k]);

            if (fDiff > fListTol)
            {
                if (error_count < iListLength)
                {
                    printf("    Loc(%d,%d)\tCPU=%.5f\tGPU=%.5f\tDiff=%.6f\n", i, j, data1[k], data2[k], fDiff);
                }

                error_count++;
            }
        }
    }

    printf(" \n  Total Errors = %d\n", error_count);
}*/

int main(int argc, char *argv[]) {
	int rank, num_proc;							//process rank and total number of processes
	double start_time, end_time, total_time;	// for timing
	int block_sz;								// Block size length for each processor to handle
	int proc_grid_sz;							// 'q' from the slides


	
	srand(time(NULL));							// Seed random numbers

/* insert MPI functions to 1) start process, 2) get total number of processors and 3) process rank*/
	MPI_Init (&argc, &argv);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	MPI_Comm_size(MPI_COMM_WORLD, &num_proc);
    
    //???

/* assign values to 1) proc_grid_sz and 2) block_sz*/
	
    proc_grid_sz=(int)sqrt((double)num_proc);
    //SZ is a #define
    //when i set this to just SZ i get 40s
    block_sz=SZ/proc_grid_sz;

    if(rank==0){
            if (SZ % proc_grid_sz != 0){
            //printf("Matrix size cannot be evenly split amongst resources!\n");
            printf("Quitting....");
            MPI_Finalize();
            exit(-1);
        }      
    }
	
        

	// Create the local matrices on each process

	double **A, **B, **C;
	A = alloc_2d_double(block_sz, block_sz);
	B = alloc_2d_double(block_sz, block_sz);
	C = alloc_2d_double(block_sz, block_sz);

	
	initialize(A, B, C, block_sz);
    //initializetoones(A,B,C,block_sz);
    //initializeToBi(A,B,C,block_sz);
    

	// Use MPI_Wtime to get the starting time
    start_time=MPI_Wtime();


	// Use SUMMA algorithm to calculate product C
	matmul(rank, proc_grid_sz, block_sz, A, B, C);
    

	// Use MPI_Wtime to get the finishing time
    end_time=MPI_Wtime();


	// Obtain the elapsed time and assign it to total_time
    total_time=end_time-start_time;

    
	// Insert statements for testing
    /*
    
    double ** testA=malloc(sizeof(double*)*6); 
    
    for(int m=0; m<6; m++){
        testA[m]=malloc(sizeof(double)*6);
        for(int j=0;j<6;j++){
            testA[m][j]=0;
        }
    }
    
    testA[0][0]=1;
    
    testA[1][0]=1;
    testA[1][1]=1;
    
    testA[2][1]=1;
    testA[2][2]=1;
    
    testA[3][2]=1;
    testA[3][3]=1;
    
    testA[4][3]=1;
    testA[4][4]=1;
    
    testA[5][4]=1;
    testA[5][5]=1;
 
    double **testB=malloc(sizeof(double*)*6);
     
    for(int m=0; m<6; m++){
        testB[m]=malloc(sizeof(double)*6);
        for(int j=0;j<6;j++){
            testB[m][j]=0;
        }
    }
    
    testB[0][0]=1;
    testB[0][1]=1;
    
    testB[1][1]=1;
    testB[1][2]=1;
    
    testB[2][2]=1;
    testB[2][3]=1;
    
    testB[3][3]=1;
    testB[3][4]=1;
    
    testB[4][4]=1;
    testB[4][5]=1;
    
    testB[5][5]=1;
    
        
    //test outs    
    //golden standard
    double **golden=malloc(sizeof(double*)*6); 
      
    for(int m=0; m<6; m++){
        golden[m]=malloc(sizeof(double)*6);
        for(int j=0;j<6;j++){
            golden[m][j]=0;
        }
    }
     
    //set gold standard
    tradMult(testA, testB, golden);
    
    //test for my implement
    double **testC=malloc(sizeof(double*)*6);
    for(int m=0; m<6; m++){
        testC[m]=malloc(sizeof(double)*6);
    }
    
    for(int i=0; i<6; i++){
        for(int j=0; j<6; j++){
            testC[i][j]=0;
        }
    }
    
     
    //set my testC
    //proc_grid_sz=(int)sqrt((double)num_proc);
	matmul(rank, 2, 3, testA, testB, testC);
    /*
     
	if (rank == 0){
        for(int i=0;i<6;i++){
            printf("\ngolden %i\n",i);
            for(int k=0;k<6;k++){
                if(golden[i][k]==1){
      //              printf("1, ");
                    //printf("%f, ",golden[i][k]);
                    printf("1, ");
                }else if(golden[i][k]==2){ 
     //               printf("2, ");
                    //printf("%f, ",golden[i][k]);
                    printf("2, ");
                }else if(golden[i][k]==0){
                    printf("0, ");
                }else{
                    //printf("x, ");
                    printf("%.*f, ",golden[i][k]);
                }
            }
        }
    }

    printf("\n");
     
	if (rank == 0){
        for(int i=0;i<6;i++){
            printf("\ntest %i\n",i);
            for(int k=0;k<6;k++){
                if(testC[i][k]==1){
                    //printf("%f, ",testC[i][k]);
                    printf("1, ");
                }else if(testC[i][k]==2){ 
                    //printf("%f, ",testC[i][k]);
                    printf("2, ");
                }else if(testC[i][k]==0){
                    printf("0, ");
                }else{
                    printf("%.*f, ",testC[i][k]);
                    //printf("x, ");
                }
            }
        }
    }
    
    int test=1;
    for(int i=0;i<6;i++){
        for(int j=0;j<6;j++){
            if(golden[i][j]!=testC[i][j]){
                test=0;
            }
        }
    }
    
    
	if (rank == 0){
        if(test==1){
            printf("\nThe test was a success!\n");
        }else{
            printf("\nThe test was a failure!\n");
        }
    }*/
    
    
    

	if (rank == 0){
		// Print in pseudo csv format for easier results compilation
		//printf("squareMatrixSideLength,%d,numMPICopies,%d,walltime,%lf\n",
			//SZ, num_proc, total_time);
        
		printf("%d,%d,%lf\n",
			SZ, num_proc, total_time);
	}

	// Destroy MPI processes
    // destroys MPI environment
    MPI_Finalize();

    
    
    /*
    for(int i=0;i<block_sz;i++){
        printf("\n");
        for(int j=0; j<block_sz; j++){
            printf("%.*f, ", C[i][j]);
        }
    }
    */
    
    
	return 0;
}
